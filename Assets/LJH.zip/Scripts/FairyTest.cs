using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FairyTest : MonoBehaviour
{
    [SerializeField] public bool fairyWithCharacter;
}
